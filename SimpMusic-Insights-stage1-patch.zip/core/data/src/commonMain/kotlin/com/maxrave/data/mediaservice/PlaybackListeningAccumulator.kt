package com.maxrave.data.mediaservice

import com.maxrave.domain.data.entities.SongEntity
import kotlin.time.TimeSource

/** A single continuous listening session. Pauses and track changes close the session. */
internal data class CompletedListeningSession(
    val song: SongEntity,
    val listenedMillis: Long,
)

/**
 * Measures real elapsed playback time from the player's progress loop. The loop only runs while
 * the player reports isPlaying, so pauses and buffering are excluded. Position deltas are used to
 * detect seeks/stalls; a discontinuity resets the baseline instead of crediting skipped audio.
 */
internal class PlaybackListeningAccumulator {
    private var song: SongEntity? = null
    private var listenedMillis: Long = 0L
    private var lastPositionMillis: Long = 0L
    private var lastTick = TimeSource.Monotonic.markNow()

    fun resume(currentSong: SongEntity?, positionMillis: Long) {
        if (currentSong == null) return
        if (song?.videoId != currentSong.videoId) {
            song = currentSong
            listenedMillis = 0L
        } else {
            // Keep accumulated time across a buffering interruption, but never count the stalled interval.
            song = currentSong
        }
        lastPositionMillis = positionMillis
        lastTick = TimeSource.Monotonic.markNow()
    }

    fun tick(currentSong: SongEntity?, positionMillis: Long): CompletedListeningSession? {
        if (currentSong == null) return null
        if (song?.videoId != currentSong.videoId) {
            val completed = finish()
            resume(currentSong, positionMillis)
            return completed
        }

        val elapsedMillis = lastTick.elapsedNow().inWholeMilliseconds.coerceAtLeast(0L)
        val positionDelta = positionMillis - lastPositionMillis
        // At the 50 ms player tick, normal playback should advance close to elapsed time. Allow
        // faster playback rates and scheduling jitter, but reject forward/backward seek jumps.
        val plausibleMaximum = elapsedMillis * 4L + 750L
        if (elapsedMillis > 0L && positionDelta >= 0L && positionDelta <= plausibleMaximum) {
            listenedMillis += elapsedMillis
        }
        lastPositionMillis = positionMillis
        lastTick = TimeSource.Monotonic.markNow()
        song = currentSong
        return null
    }

    fun pause(positionMillis: Long) {
        if (song == null) return
        lastPositionMillis = positionMillis
        lastTick = TimeSource.Monotonic.markNow()
    }

    fun seek(positionMillis: Long) {
        if (song == null) return
        lastPositionMillis = positionMillis
        lastTick = TimeSource.Monotonic.markNow()
    }

    fun finish(): CompletedListeningSession? {
        val currentSong = song
        val duration = listenedMillis
        song = null
        listenedMillis = 0L
        lastPositionMillis = 0L
        lastTick = TimeSource.Monotonic.markNow()
        return if (currentSong != null && duration > 0L) {
            CompletedListeningSession(currentSong, duration)
        } else {
            null
        }
    }
}
